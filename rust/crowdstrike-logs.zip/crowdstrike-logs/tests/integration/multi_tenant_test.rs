crowdstrike-log-collector/
├── Cargo.toml                    # Workspace manifest
├── config.toml                   # Runtime config (multi-tenant)
├── src/
│   ├── main.rs                   # Entry point
│   ├── config/                   # Configuration management
│   │   ├── mod.rs                # Module entry
│   │   ├── tenant_config.rs      # Tenant configuration handling
│   │   └── hot_reload.rs         # Hot reloading logic
│   ├── collectors/                # Collectors for different sources
│   │   ├── mod.rs                # Module entry
│   │   ├── alerts.rs             # Alerts collector
│   │   ├── audit_events.rs       # Audit events collector
│   │   └── hosts.rs              # Hosts collector
│   ├── outputs/                  # Output handlers
│   │   ├── mod.rs                # Module entry
│   │   ├── json_file.rs          # JSON file output handler
│   │   └── http_post.rs          # HTTP POST output handler
│   ├── metrics/                  # Metrics collection
│   │   ├── mod.rs                # Module entry
│   │   └── metrics.rs            # Metrics handling
│   ├── state/                    # State management
│   │   ├── mod.rs                # Module entry
│   │   └── state_manager.rs      # State persistence
│   └── utils/                    # Utility functions
│       ├── mod.rs                # Module entry
│       └── secrets.rs            # Secure secret handling
└── tests/                        # Integration tests
    ├── integration.rs            # Integration tests for the collector
    └── unit.rs                   # Unit tests