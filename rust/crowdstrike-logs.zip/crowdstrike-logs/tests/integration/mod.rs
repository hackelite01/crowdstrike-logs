Cargo.toml                    # workspace manifest
config.toml                   # runtime config (multi-tenant)
state.json                    # persisted collector state (auto-created)
crates/
  cs-state/                   # state persistence (StateManager)
  cs-output/                  # output handlers (JSON file, HTTP POST, dispatcher)
  cs-collector/               # API client, auth, collectors (alerts/audit/hosts)
  cs-main/                    # entry point, supervisor, config, metrics
  cs-secrets/                 # secure secret handling
  cs-watcher/                 # hot-reload file watcher