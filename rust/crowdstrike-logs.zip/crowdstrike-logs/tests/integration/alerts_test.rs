crowdstrike-log-collector/
├── Cargo.toml                    # Workspace manifest
├── config/
│   ├── config.toml               # Runtime config for tenants
│   └── secrets.toml              # Secure secrets (encrypted or managed)
├── src/
│   ├── main.rs                   # Entry point
│   ├── config.rs                 # Configuration loading and hot-reloading
│   ├── tenant.rs                 # Tenant management and handling
│   ├── collector.rs               # Core collector logic
│   ├── output/
│   │   ├── mod.rs                # Output module
│   │   ├── json_file.rs          # JSON file output handler
│   │   └── http_post.rs          # HTTP POST output handler
│   ├── metrics.rs                # Metrics collection and reporting
│   ├── logging.rs                # Logging setup and management
│   └── state.rs                  # State persistence and management
└── tests/
    ├── integration.rs            # Integration tests
    └── unit.rs                   # Unit tests