crowdstrike-log-collector/
├── Cargo.toml                    # Workspace manifest
├── config/
│   ├── config.toml               # Default configuration
│   └── tenant_configs/            # Directory for tenant-specific configs
│       ├── tenant1.toml
│       └── tenant2.toml
├── src/
│   ├── main.rs                    # Entry point
│   ├── config_manager.rs          # Configuration management (hot-reloading)
│   ├── secret_manager.rs          # Secure secret handling
│   ├── collectors/
│   │   ├── mod.rs                 # Module for collectors
│   │   ├── alerts_collector.rs    # Alerts collector
│   │   ├── audit_events_collector.rs # Audit events collector
│   │   └── hosts_collector.rs     # Hosts collector
│   ├── outputs/
│   │   ├── mod.rs                 # Module for output handlers
│   │   ├── json_file_output.rs    # JSON file output handler
│   │   └── http_post_output.rs    # HTTP POST output handler
│   ├── metrics.rs                 # Metrics collection and reporting
│   └── logging.rs                 # Logging setup
└── tests/
    ├── integration.rs             # Integration tests
    └── unit.rs                    # Unit tests