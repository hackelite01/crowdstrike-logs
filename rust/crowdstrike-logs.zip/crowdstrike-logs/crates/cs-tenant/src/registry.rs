crowdstrike-log-collector/
├── Cargo.toml                    # Workspace manifest
├── config/                       # Configuration files for tenants
│   ├── tenant1.toml              # Tenant 1 configuration
│   ├── tenant2.toml              # Tenant 2 configuration
│   └── ...
├── secrets/                      # Secret management
│   ├── vault.rs                  # Vault integration for secret handling
│   └── local_cache.rs            # Local caching for secrets
├── src/
│   ├── main.rs                   # Entry point
│   ├── config.rs                 # Configuration management
│   ├── collector.rs              # Core collector logic
│   ├── api_client.rs             # API client for CrowdStrike
│   ├── output/
│   │   ├── json_file.rs          # JSON file output handler
│   │   └── http_post.rs          # HTTP POST output handler
│   ├── metrics.rs                # Metrics collection
│   ├── logging.rs                # Logging setup
│   └── state.rs                  # State management
└── tests/                        # Integration tests
    ├── integration.rs            # Integration tests for the collector
    └── ...