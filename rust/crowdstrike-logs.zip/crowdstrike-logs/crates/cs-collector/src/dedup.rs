Cargo.toml                    # workspace manifest
src/
  main.rs                     # entry point
  config/
    mod.rs                    # configuration management
    tenant_config.rs          # tenant-specific configuration
  collectors/
    mod.rs                    # collector module
    alerts.rs                 # alerts collector
    audit_events.rs           # audit events collector
    hosts.rs                  # hosts collector
  outputs/
    mod.rs                    # output handlers
    json_file.rs              # JSON file output handler
    http_post.rs              # HTTP POST output handler
  metrics/
    mod.rs                    # metrics collection and reporting
  secrets/
    mod.rs                    # secret management
    env.rs                    # environment variable handling
    vault.rs                  # integration with secret management services
  state/
    mod.rs                    # state management
    state_manager.rs          # state persistence logic