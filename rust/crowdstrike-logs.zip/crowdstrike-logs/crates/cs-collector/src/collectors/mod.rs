crowdstrike-log-collector/
├── Cargo.toml                    # Workspace manifest
├── config/
│   ├── config.toml               # Main configuration file
│   └── tenants/                   # Directory for tenant-specific configurations
│       ├── tenant1.toml
│       └── tenant2.toml
├── src/
│   ├── main.rs                    # Entry point
│   ├── config.rs                  # Configuration loading and hot reloading
│   ├── secrets.rs                 # Secure secret handling
│   ├── metrics.rs                 # Metrics collection
│   ├── logging.rs                 # Logging setup
│   ├── collector/
│   │   ├── mod.rs                 # Module for collectors
│   │   ├── alerts.rs              # Alerts collector
│   │   ├── audit_events.rs        # Audit events collector
│   │   └── hosts.rs               # Hosts collector
│   └── state.rs                   # State management
└── tests/
    ├── integration.rs             # Integration tests
    └── unit.rs                    # Unit tests