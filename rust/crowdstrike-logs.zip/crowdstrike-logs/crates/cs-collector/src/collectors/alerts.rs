crowdstrike-log-collector/
├── Cargo.toml                    # Workspace manifest
├── config/
│   ├── tenant1.toml              # Configuration for tenant 1
│   ├── tenant2.toml              # Configuration for tenant 2
│   └── config_manager.rs          # Configuration management logic
├── secrets/
│   ├── secret_manager.rs          # Secret management logic
│   └── env_encryption.rs          # Environment variable encryption
├── src/
│   ├── main.rs                    # Entry point
│   ├── collector/
│   │   ├── mod.rs                 # Module for collectors
│   │   ├── alerts.rs              # Alerts collector
│   │   ├── audit_events.rs        # Audit events collector
│   │   └── hosts.rs               # Hosts collector
│   ├── output/
│   │   ├── mod.rs                 # Module for output handlers
│   │   ├── json_file.rs           # JSON file output handler
│   │   └── http_post.rs           # HTTP POST output handler
│   ├── metrics/
│   │   ├── mod.rs                 # Module for metrics collection
│   │   └── metrics.rs             # Metrics implementation
│   ├── logging/
│   │   ├── mod.rs                 # Module for logging
│   │   └── logger.rs              # Logger implementation
│   └── utils/
│       ├── mod.rs                 # Utility functions
│       └── file_watcher.rs        # File watcher for hot reloading
└── tests/
    ├── integration.rs             # Integration tests
    └── unit.rs                    # Unit tests