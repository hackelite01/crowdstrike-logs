crowdstrike-log-collector/
├── Cargo.toml                    # Workspace manifest
├── config/
│   ├── config.toml               # Default configuration
│   └── tenant_configs/            # Directory for tenant-specific configurations
│       ├── tenant1.toml
│       └── tenant2.toml
├── src/
│   ├── main.rs                    # Entry point
│   ├── config_manager.rs          # Configuration management (hot-reloading)
│   ├── secrets_manager.rs         # Secure secret handling
│   ├── metrics.rs                 # Metrics collection
│   ├── logging.rs                 # Logging setup
│   ├── collectors/
│   │   ├── mod.rs                 # Module for collectors
│   │   ├── alerts.rs              # Alerts collector
│   │   ├── audit_events.rs        # Audit events collector
│   │   └── hosts.rs               # Hosts collector
│   ├── outputs/
│   │   ├── mod.rs                 # Module for output handlers
│   │   ├── json_file.rs           # JSON file output handler
│   │   └── http_post.rs           # HTTP POST output handler
│   └── state/
│       ├── mod.rs                 # Module for state management
│       └── state_manager.rs       # State persistence
└── tests/
    ├── integration.rs             # Integration tests
    └── unit.rs                    # Unit tests