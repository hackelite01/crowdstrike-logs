/crowdstrike-log-collector
├── Cargo.toml                    # Workspace manifest
├── config.toml                   # Runtime config
├── state.json                    # Persisted collector state (auto-created)
├── crates/
│   ├── cs-state/                 # State persistence (StateManager)
│   ├── cs-output/                # Output handlers (JSON file, HTTP POST, dispatcher)
│   ├── cs-collector/             # API client, auth, collectors (alerts/audit/hosts)
│   ├── cs-main/                  # Entry point, supervisor, config, metrics
│   ├── cs-config/                # Configuration management (hot-reloading)
│   ├── cs-secrets/               # Secure secret handling
│   └── cs-metrics/               # Metrics collection and reporting
└── logs/                          # Output logs directory