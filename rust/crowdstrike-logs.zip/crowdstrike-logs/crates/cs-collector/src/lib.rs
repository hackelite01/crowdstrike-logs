crowdstrike-log-collector/
├── Cargo.toml                    # Workspace manifest
├── config.toml                   # Runtime config
├── state.json                    # Persisted collector state (auto-created)
├── crates/
│   ├── cs-state/                 # State persistence (StateManager)
│   ├── cs-output/                # Output handlers (JSON file, HTTP POST, dispatcher)
│   ├── cs-collector/             # API client, auth, collectors (alerts/audit/hosts)
│   ├── cs-metrics/               # Metrics collection and reporting
│   ├── cs-tenant/                # Multi-tenant management
│   ├── cs-config/                # Configuration management and hot reloading
│   └── cs-secrets/               # Secure secret handling
└── examples/
    └── multi_tenant_example.rs    # Example of multi-tenant configuration