Cargo.toml                    # workspace manifest
src/
  main.rs                     # entry point
  config.rs                   # configuration management
  secrets.rs                  # secret handling
  tenant.rs                   # tenant management
  collector.rs                # core collector logic
  outputs/
    mod.rs                    # module for output handlers
    json_file.rs              # JSON file output handler
    http_post.rs              # HTTP POST output handler
  metrics.rs                  # metrics collection
  logging.rs                  # logging setup
  state.rs                    # state persistence
  utils.rs                    # utility functions