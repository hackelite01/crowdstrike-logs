Cargo.toml                    # workspace manifest
src/
  main.rs                     # entry point
  config.rs                   # configuration management
  secrets.rs                  # secret handling
  metrics.rs                  # metrics collection
  logging.rs                  # logging setup
  tenant_manager.rs           # multi-tenant management
  collectors/
    mod.rs                    # module for collectors
    alerts.rs                 # alerts collector
    audit_events.rs           # audit events collector
    hosts.rs                  # hosts collector
  outputs/
    mod.rs                    # module for output handlers
    json_file.rs              # JSON file output handler
    http_post.rs              # HTTP POST output handler
  state.rs                    # state persistence