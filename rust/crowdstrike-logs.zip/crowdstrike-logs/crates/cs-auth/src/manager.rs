   /crowdstrike-log-collector
   ├── Cargo.toml
   ├── config.toml
   ├── state.json
   ├── crates/
   │   ├── cs-api/                # API client for CrowdStrike
   │   ├── cs-collector/          # Collectors for different data sources
   │   ├── cs-output/             # Output handlers (file, HTTP)
   │   ├── cs-config/             # Configuration management
   │   ├── cs-secrets/            # Secure secret handling
   │   └── cs-main/               # Entry point and supervisor
   └── logs/                      # Output logs directory