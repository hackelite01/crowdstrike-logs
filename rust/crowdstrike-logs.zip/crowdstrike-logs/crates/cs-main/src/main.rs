crowdstrike-log-collector/
├── Cargo.toml                    # Workspace manifest
├── config/
│   ├── config.toml               # Runtime config for tenants
│   └── secrets.toml              # Secrets configuration (encrypted)
├── src/
│   ├── main.rs                   # Entry point
│   ├── config.rs                 # Configuration management (loading, validation, hot-reloading)
│   ├── tenant.rs                 # Tenant management (credentials, state)
│   ├── collector.rs               # Core collector logic (polling, data handling)
│   ├── output/
│   │   ├── mod.rs                # Output module
│   │   ├── json_file.rs          # JSON file output handler
│   │   └── http_post.rs          # HTTP POST output handler
│   ├── metrics.rs                # Metrics collection and reporting
│   ├── logging.rs                # Logging setup and management
│   └── utils.rs                  # Utility functions (e.g., encryption/decryption)
└── tests/
    ├── integration.rs            # Integration tests
    └── unit.rs                   # Unit tests