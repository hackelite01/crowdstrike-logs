crowdstrike-log-collector/
├── Cargo.toml                    # Workspace manifest
├── config.toml                   # Runtime config (optional)
├── src/
│   ├── main.rs                   # Entry point
│   ├── config/
│   │   ├── mod.rs                # Module for configuration management
│   │   ├── tenant_config.rs       # Tenant configuration structure
│   ├── secrets/
│   │   ├── mod.rs                # Module for secret management
│   │   ├── vault.rs              # Vault integration for secret handling
│   ├── api/
│   │   ├── mod.rs                # Module for API client
│   │   ├── client.rs             # API client implementation
│   ├── collector/
│   │   ├── mod.rs                # Module for the collector
│   │   ├── tenant_collector.rs    # Collector for individual tenants
│   ├── output/
│   │   ├── mod.rs                # Module for output handling
│   │   ├── json_file.rs          # JSON file output handler
│   │   ├── http_post.rs          # HTTP POST output handler
│   ├── metrics/
│   │   ├── mod.rs                # Module for metrics collection
│   │   ├── metrics.rs            # Metrics implementation
│   ├── logging/
│   │   ├── mod.rs                # Module for logging setup
│   │   ├── logger.rs             # Logger implementation
└── tests/
    ├── integration.rs            # Integration tests
    └── unit.rs                   # Unit tests