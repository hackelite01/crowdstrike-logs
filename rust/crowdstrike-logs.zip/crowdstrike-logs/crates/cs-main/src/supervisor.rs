Cargo.toml                    # workspace manifest
src/
  main.rs                     # entry point
  config/
    mod.rs                    # configuration module
    config_manager.rs         # handles loading and hot reloading of configurations
  secrets/
    mod.rs                    # secret management module
  collectors/
    mod.rs                    # main collector module
    alerts.rs                 # alerts collector
    audit_events.rs           # audit events collector
    hosts.rs                  # hosts collector
  outputs/
    mod.rs                    # output handlers module
    json_file.rs              # JSON file output handler
    http_post.rs              # HTTP POST output handler
  metrics/
    mod.rs                    # metrics collection module
  state/
    mod.rs                    # state management module
    state_manager.rs          # handles state persistence
  logging/
    mod.rs                    # logging module
    logger.rs                 # structured logging implementation