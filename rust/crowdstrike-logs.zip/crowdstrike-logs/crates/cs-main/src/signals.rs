crowdstrike-log-collector/
├── Cargo.toml                    # Workspace manifest
├── config/
│   ├── tenant1.toml              # Tenant 1 configuration
│   ├── tenant2.toml              # Tenant 2 configuration
│   └── config_manager.rs          # Configuration management and hot reloading
├── secrets/
│   ├── secret_manager.rs          # Secure secret handling
├── src/
│   ├── main.rs                    # Entry point
│   ├── collector/
│   │   ├── mod.rs                 # Module for collectors
│   │   ├── alerts.rs              # Alerts collector
│   │   ├── audit_events.rs        # Audit events collector
│   │   └── hosts.rs               # Hosts collector
│   ├── output/
│   │   ├── mod.rs                 # Module for output handlers
│   │   ├── json_file.rs           # JSON file output handler
│   │   └── http_post.rs           # HTTP POST output handler
│   ├── state/
│   │   ├── mod.rs                 # State management
│   │   └── state_manager.rs       # State persistence
│   ├── metrics/
│   │   ├── mod.rs                 # Metrics collection
│   │   └── metrics_manager.rs      # Metrics handling
│   └── logging/
│       ├── mod.rs                 # Logging setup
│       └── logger.rs              # Logger implementation
└── tests/
    ├── integration.rs             # Integration tests
    └── unit.rs                    # Unit tests