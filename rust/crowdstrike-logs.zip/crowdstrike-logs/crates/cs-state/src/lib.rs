Cargo.toml                    # workspace manifest
src/
  main.rs                     # entry point
  config.rs                   # configuration management
  tenant.rs                   # tenant management
  collector.rs                # core collector logic
  output/
    mod.rs                    # output module
    json_file.rs              # JSON file output handler
    http_post.rs              # HTTP POST output handler
  state.rs                    # state persistence
  metrics.rs                  # metrics collection
  secrets.rs                  # secret management
  utils.rs                    # utility functions