crowdstrike-log-collector/
├── Cargo.toml                    # Workspace manifest
├── config/
│   ├── tenant1.toml              # Configuration for tenant 1
│   ├── tenant2.toml              # Configuration for tenant 2
│   └── config_manager.rs         # Configuration management and hot-reloading
├── secrets/
│   ├── secret_manager.rs         # Secure secret handling
├── src/
│   ├── main.rs                   # Entry point
│   ├── collector.rs              # Core collector logic
│   ├── api_client.rs             # API client for CrowdStrike
│   ├── output/
│   │   ├── json_file.rs          # JSON file output handler
│   │   └── http_post.rs          # HTTP POST output handler
│   ├── metrics.rs                # Metrics collection
│   ├── logging.rs                # Logging setup
│   └── state.rs                  # State management
└── tests/
    ├── integration.rs            # Integration tests
    └── unit.rs                   # Unit tests