crowdstrike-log-collector/
├── Cargo.toml                    # Workspace manifest
├── config/
│   ├── tenant1.toml              # Tenant 1 configuration
│   ├── tenant2.toml              # Tenant 2 configuration
│   └── config_manager.rs          # Configuration management module
├── secrets/
│   ├── secret_manager.rs          # Secret management module
│   └── env_encryption.rs          # Environment variable encryption
├── src/
│   ├── main.rs                    # Entry point
│   ├── collector/
│   │   ├── mod.rs                 # Collector module
│   │   ├── alerts.rs              # Alerts collector
│   │   ├── audit_events.rs        # Audit events collector
│   │   └── hosts.rs               # Hosts collector
│   ├── output/
│   │   ├── mod.rs                 # Output module
│   │   ├── json_file.rs           # JSON file output handler
│   │   └── http_post.rs           # HTTP POST output handler
│   ├── state/
│   │   ├── mod.rs                 # State management module
│   │   └── state_manager.rs       # State persistence
│   ├── metrics/
│   │   ├── mod.rs                 # Metrics module
│   │   └── metrics_collector.rs   # Metrics collection
│   └── utils/
│       ├── mod.rs                 # Utility functions
│       └── file_watcher.rs        # File watcher for hot reloading
└── tests/
    ├── integration.rs             # Integration tests
    └── unit.rs                    # Unit tests