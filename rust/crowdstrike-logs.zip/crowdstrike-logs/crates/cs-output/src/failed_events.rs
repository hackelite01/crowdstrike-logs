crowdstrike-log-collector/
├── Cargo.toml                    # Workspace manifest
├── config.toml                   # Runtime config
├── state.json                    # Persisted collector state (auto-created)
├── crates/
│   ├── cs-collector/             # Main collector logic
│   │   ├── src/
│   │   │   ├── main.rs            # Entry point
│   │   │   ├── collector.rs       # Collector logic for each tenant
│   │   │   ├── config.rs          # Configuration management
│   │   │   ├── secrets.rs         # Secret handling
│   │   │   ├── logging.rs         # Logging setup
│   │   │   ├── metrics.rs         # Metrics collection
│   │   │   └── utils.rs           # Utility functions
│   │   └── Cargo.toml             # Manifest for cs-collector
│   ├── cs-api/                    # API client for CrowdStrike
│   │   ├── src/
│   │   │   ├── api_client.rs      # API client implementation
│   │   │   └── models.rs          # Data models for API responses
│   │   └── Cargo.toml             # Manifest for cs-api
│   ├── cs-output/                 # Output handlers
│   │   ├── src/
│   │   │   ├── json_file.rs       # JSON file output handler
│   │   │   ├── http_post.rs       # HTTP POST output handler
│   │   │   └── dispatcher.rs      # Event dispatcher
│   │   └── Cargo.toml             # Manifest for cs-output
│   └── cs-state/                  # State persistence
│       ├── src/
│       │   └── state_manager.rs   # State management logic
│       └── Cargo.toml             # Manifest for cs-state
└── README.md                      # Project documentation