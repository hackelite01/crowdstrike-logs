Cargo.toml                    # workspace manifest
src/
  main.rs                     # entry point
  config.rs                   # configuration management
  tenant_manager.rs           # multi-tenant management
  collector.rs                # collector trait and implementations
  output.rs                   # output handlers
  metrics.rs                  # metrics collection
  logging.rs                  # logging setup
  state.rs                    # state persistence
  crates/
    cs-state/                 # state persistence (StateManager)
    cs-output/                # output handlers (JSON file, HTTP POST, dispatcher)
    cs-collector/             # API client, auth, collectors (alerts/audit/hosts)
    cs-main/                  # main logic, supervisor, config, metrics